import React from 'react';
import { PlaySquare, ListVideo, Search, Image as ImageIcon, Store, BrainCircuit, Bot } from 'lucide-react';
import { TabType } from '../App';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export function Layout({ children, activeTab, setActiveTab }: LayoutProps) {
  const navItems = [
    { id: 'indexer', label: 'Indexer', icon: PlaySquare },
    { id: 'playlists', label: 'Playlists', icon: ListVideo },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'gallery', label: 'Gallery', icon: ImageIcon },
    { id: 'store', label: 'Store', icon: Store },
    { id: 'mindmap', label: 'Mind Map', icon: BrainCircuit },
  ] as const;

  return (
    <div className="min-h-screen relative bg-slate-900 text-white overflow-x-hidden font-sans">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-700/30 blur-[120px] animate-float"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-purple-700/20 blur-[120px] animate-float-delayed"></div>
        <div className="absolute top-[40%] left-[40%] w-[30%] h-[30%] rounded-full bg-pink-600/20 blur-[100px] animate-float-slow"></div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 liquid-glass border-b-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/20">
                <span className="text-2xl">🎬</span>
              </div>
              <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-200">
                Playlist Navigator <span className="font-light opacity-70">Pro</span>
              </h1>
            </div>

            <nav className="hidden md:flex gap-1 p-1 liquid-glass-sm rounded-full border-0">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 transition-all ${
                    activeTab === item.id
                      ? 'liquid-glass-sm shadow-[0_0_20px_rgba(255,255,255,0.1)] text-white border-0'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <item.icon size={16} />
                  {item.label}
                </button>
              ))}
              <button
                onClick={() => setActiveTab('assistant')}
                className={`px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 transition-all ${
                  activeTab === 'assistant'
                    ? 'bg-gradient-to-r from-purple-500/40 to-pink-500/40 text-white border border-purple-500/80 shadow-[0_0_20px_rgba(168,85,247,0.3)]'
                    : 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-white border border-purple-500/30 hover:border-purple-500/60 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                }`}
              >
                <Bot size={16} />
                Assistant
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        {children}
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 mt-12 py-6">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-sm text-white/50">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
            <span>API Quota: <strong className="text-white">4,230</strong> / 10,000</span>
          </div>
          <div>40 playlists | 1684 videos</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <span>v2.5.0 (Liquid Glass)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
