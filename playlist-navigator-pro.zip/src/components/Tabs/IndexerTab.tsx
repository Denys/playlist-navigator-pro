import React, { useState } from 'react';
import { PlaySquare } from 'lucide-react';

export function IndexerTab() {
  const [url, setUrl] = useState('');
  const [name, setName] = useState('');
  const [color, setColor] = useState('purple');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle indexing logic
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="liquid-glass rounded-3xl p-8">
        <h2 className="text-3xl font-bold text-white mb-2">Index YouTube Playlist</h2>
        <p className="text-white/70 mb-8">Extract and index playlist videos with descriptions and metadata.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-white/80 mb-2">Playlist URL</label>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full px-4 py-3 liquid-glass-sm border-0 rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              placeholder="https://youtube.com/playlist?list=..."
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-white/80 mb-2">Playlist Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 liquid-glass-sm border-0 rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              placeholder="My Study Mix"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-white/80 mb-3">Color Scheme</label>
            <div className="flex gap-3">
              {['purple', 'teal', 'blue', 'green'].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-10 h-10 rounded-full bg-gradient-to-br border-2 transition-all ${
                    c === 'purple' ? 'from-purple-500 to-purple-700' :
                    c === 'teal' ? 'from-teal-400 to-teal-600' :
                    c === 'blue' ? 'from-blue-500 to-blue-700' :
                    'from-green-500 to-green-700'
                  } ${
                    color === c
                      ? 'border-white shadow-lg ring-2 ring-white ring-offset-2 ring-offset-slate-900 opacity-100'
                      : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl font-semibold text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
          >
            <PlaySquare size={20} />
            Index Playlist
          </button>
        </form>
      </div>
    </div>
  );
}
